#include "Obstacle.h"

void Obstacle::update() {

}